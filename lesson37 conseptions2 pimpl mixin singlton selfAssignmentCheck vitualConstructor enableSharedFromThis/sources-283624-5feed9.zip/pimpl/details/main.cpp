// # time g++ -c solution/main.cpp
// real    0m0.020s
// user    0m0.012s
// sys     0m0.008s

#include "my_class.h"

int main() {

	my::my_class cls{"test_file.txt"};

	return 0;
}