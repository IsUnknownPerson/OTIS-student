#pragma once

#include "my_class.h"

void do_something_with_my_class(const my::my_class& m);