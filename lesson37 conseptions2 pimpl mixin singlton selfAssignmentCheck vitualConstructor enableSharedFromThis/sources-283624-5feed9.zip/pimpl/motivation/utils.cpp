#include "utils.h"

void do_something_with_my_class(const my::my_class& m) {
	m.do_work();
}