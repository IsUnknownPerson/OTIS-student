#pragma once 

#include <gamestate/gamestate.h>

namespace visualize {

	void draw_field(const gamestate::State* const field, int size);

} // namespace visualize
