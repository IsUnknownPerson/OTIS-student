#include <algorithm>
#include <iostream>
#include <iterator>
#include <list>
#include <string>
#include <vector>

template <typename T>
std::ostream &operator<<(std::ostream &os, const std::vector<T> &values) {
	for (auto &v : values)
		std::cout << v << ' ';
	return os;
}

template <typename T>
std::ostream &operator<<(std::ostream &os, const std::list<T> &values) {
	for (auto &v : values)
		std::cout << v << ' ';
	return os;
}

void test_remove() {
	std::cout << "\ntest_remove\n";

	std::vector<int> values{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0};

	std::cout << "values before remove:\n"
			  << values << std::endl;

	// ForwardIt remove_if( ForwardIt first, ForwardIt last, UnaryPredicate p );
	auto iter = std::remove_if(values.begin(), values.end(),
							   [](int v) { return v < 5; });

	std::cout << "values after remove:\n"
			  << values << std::endl;
	std::cout << "iter: [" << std::distance(values.begin(), iter)
			  << "] = " << *iter << std::endl;

	values.erase(iter, values.end());
	std::cout << "values after erase:\n"
			  << values << std::endl;
}

void test_transform() {
    std::vector<std::string> names{
            "Vasia",
            "Petia",
            "Alexander",
            "Liza"};

    std::vector<std::size_t> sizes;

    std::transform(names.cbegin(), names.cend(),
                   std::back_inserter(sizes),
                   [](const std::string &name) {
                       return name.size();
                   });

    std::cout << "sizes after transform:\n"
              << sizes << std::endl;

    // OutputIt transform( InputIt1 first1, InputIt1 last1, InputIt2 first2,
    //                 OutputIt d_first, BinaryOperation binary_op );

    std::vector<std::string> names_sizes;

    std::transform(names.cbegin(), names.cend(),
                   sizes.cbegin(),
                   std::back_inserter(names_sizes),
                   [](const std::string &name, std::size_t size) {
                       return name + '_' + std::to_string(size);
                   });

    std::cout << "names_sizes after transform:\n"
              << names_sizes << std::endl;
}

void test_remove_copy() {
	std::cout << "\ntest_remove_copy\n";

	std::vector<int> values = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

	std::list<int> dest;
	std::remove_copy_if(values.cbegin(), values.cend(),
						std::front_inserter(dest),
						[](int v) { return v < 5; });

	std::cout << "values after remove_copy_if:\n"
			  << values << std::endl;

    values.erase(values.cbegin() + (values.size() - dest.size()), values.cend());

    std::cout << "values after erase:\n"
              << values << std::endl;

	std::cout << "dest after remove_copy_if:\n"
			  << dest << std::endl;
}

int main() {
	test_remove();
    test_transform();
	test_remove_copy();
}