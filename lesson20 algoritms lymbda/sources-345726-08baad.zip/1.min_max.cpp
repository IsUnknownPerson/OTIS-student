#include <algorithm>
#include <iostream>
#include <vector>

template <typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<T>& values) {
    for (auto& v: values)
        std::cout << v << ' ';
    return os;
}


// - STL algos use iterators interface.
//
// - Iterators interface allows using of STL containers, or implement
//   own container, support iterators interface, and use STL algos.
//
// - Usual STL algo behavior - accept a range (begin and end), it allows
//   limiting range, use not the whole container for the algo.

void minMax() {
    std::vector<int> values = {3, 0, 4, 1, 2};

    std::cout << "Values:\n"
              << values << std::endl;

    auto minIter = std::min_element(values.cbegin(), values.cend());
    std::cout << "Min element at: "
              << std::distance(values.cbegin(), minIter)
              << " = " << *minIter << std::endl;

    auto maxIter = std::max_element(values.cbegin(), values.cend());
    std::cout << "Max element at: "
              << std::distance(values.cbegin(), maxIter)
              << " = " << *maxIter << std::endl;

    auto minMax = std::minmax_element(values.cbegin(), values.cend());

    // check end in general case
    if (minMax.second != values.cend()) {
        std::cout << "Min-Max.second element at: "
                  << std::distance(values.cbegin(), minMax.second)
                  << " = " << *minMax.second << std::endl;
    }
}

int correctMaxNumberByIf(int maxNumber) {
    if (maxNumber < 1) {
        return 1;
    }
    if (maxNumber > 100) {
        return 100;
    }
    return maxNumber;
}

int correctMaxNumberWithMinMax(int maxNumber) {
    return std::max( std::min(maxNumber, 100), 1);
}

int correctMaxNumberClamp(int maxNumber) {
    return std::clamp(maxNumber, 1, 100);
}

void correctMaxNumber() {
    correctMaxNumberByIf(42);
    correctMaxNumberWithMinMax(42);
    correctMaxNumberClamp(42);
}

int main() {
    minMax();
    correctMaxNumber();
}