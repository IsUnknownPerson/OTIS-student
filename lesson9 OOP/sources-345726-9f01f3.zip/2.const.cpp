#include <cstddef>
#include <string>
#include <iostream>

class String {
public:
    String(const char* cString): data{cString} { }
    std::size_t length() const {
        return data.size();
    }
private:
    std::string data;
};

void foo(const String& s) {
    std::cout << "string length " << s.length() << std::endl;
}

void base() {
    const String s("Hello!");
    foo(s); //ok
}

namespace text {
    class Surface{};

    class Text {
    public:
        void render(Surface& target) const {}

        void set(const std::string& text) {
            this->text = text;
        }

        std::string get() const {
            return text;
        }
    private:
        std::string text;
    };

//возможная реализация
    void show(const Text& text, Surface& s) {
        if (text.get().empty()) {
            Text tmp; tmp.set("<none>"); tmp.render(s);
        } else {
            text.render(s);
        }
    }
}


int main() {
    base();
}