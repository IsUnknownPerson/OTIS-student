// Разберем на вебинаре "Полиморфизм и все-все-все"

class Rect {
public:
    void setWidth(double);
    void setHeight(double);
};

class Square {
public:
    void setArea(double);
};

int main() {}