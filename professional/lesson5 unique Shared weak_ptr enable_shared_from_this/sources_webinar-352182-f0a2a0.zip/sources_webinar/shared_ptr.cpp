#include "pretty.h"
#include "utils.h"

#include <memory>
#include <functional>

class A {
  public:
    A() { std::cout << __PRETTY_FUNCTION__ << std::endl; }
    ~A() { std::cout << __PRETTY_FUNCTION__ << std::endl; }
};

template <typename T>
class shared_ptr {
    struct ctrl_block {
        std::size_t counter;
        std::size_t weak_counter;
        /* deleater and smth else */
        ctrl_block() : counter{1UL}, weak_counter{0UL} {}
    };
    ctrl_block *ctrl;
    T *ptr;

  public:
    shared_ptr(T *ptr_) : ctrl{new ctrl_block}, ptr{ptr_} {}

    shared_ptr(const shared_ptr &other) : ctrl{other.ctrl}, ptr{other.ptr} {
        ++ctrl->counter;
    }

    ~shared_ptr() {
        if (--ctrl->counter == 0) {
            delete (ptr);
            if (ctrl->weak_counter == 0)
                delete (ctrl);
        }
    }
};

void shared_ptr_example() {
    std::cout << __PRETTY_FUNCTION__ << std::endl;

    shared_ptr<A> ptr1(new A);
    auto ptr2 = ptr1;
}

void delete_A(A *ptr) { delete ptr; }

void size_of() {
    std::cout << __PRETTY_FUNCTION__ << std::endl;

    A *row_ptr = nullptr;
    std::shared_ptr<A> ptr1(new A);
    std::shared_ptr<A> ptr2(new A, delete_A);

    auto lam = [](A *ptr) { delete ptr; };
    std::shared_ptr<A> ptr3(new A, lam);

    int some_value = 42;
    auto lam2      = [&some_value](A *ptr) { delete ptr; };
    std::shared_ptr<A> ptr4(new A, lam2);

    PRETTY_COUT(sizeof(row_ptr), sizeof(ptr1), sizeof(ptr2), sizeof(ptr3),
                sizeof(ptr4));
}

template <typename T, typename Deleter>
class unique_ptr__
{
    T* ptr;
    Deleter d;
};

template <typename Deleter>
struct ControlBlock {
    Deleter d;
};

template <typename T>
class shared_ptr__
{
public:
    template <typename Deleter>
    shared_ptr__(T* ptr_, Deleter d)
    {
        controlBlock = static_cast<void*>(new ControlBlock<Deleter>());
    }

    T* ptr;
    void* controlBlock;
};

class partnerA;
class partnerB;

class partnerA {
    std::shared_ptr<partnerB> partner_ptr;

  public:
    partnerA() { std::cout << __PRETTY_FUNCTION__ << std::endl; }
    ~partnerA() { std::cout << __PRETTY_FUNCTION__ << std::endl; }
    void setPartner(std::shared_ptr<partnerB> ptr) { partner_ptr = ptr; }
};

class partnerB {
    std::shared_ptr<partnerA> partner_ptr;

  public:
    partnerB() { std::cout << __PRETTY_FUNCTION__ << std::endl; }
    ~partnerB() { std::cout << __PRETTY_FUNCTION__ << std::endl; }

    void setPartner(std::shared_ptr<partnerA> ptr) { partner_ptr = ptr; }
};

void cyclik_links() {
    std::cout << __PRETTY_FUNCTION__ << std::endl;

    auto first  = std::make_shared<partnerA>();
    auto second = std::make_shared<partnerB>();

    first->setPartner(second); //second counter = 2
    second->setPartner(first); //first counter = 2

    //first.~shared_ptr() => counter = 1, but not destructor of partnerA will be called, second counter = 2
    //second.~shared_ptr() => counter = 1, but not destructor of partnerB will be called
}

// class SharableObj {
//   public:
//     SharableObj() { std::cout << __PRETTY_FUNCTION__ << std::endl; }
//     ~SharableObj() { std::cout << __PRETTY_FUNCTION__ << std::endl; }

//     auto getPtr() { return std::shared_ptr<SharableObj>(this); }
// };

class SharableObj : public std::enable_shared_from_this<SharableObj> {
  public:
    SharableObj() { std::cout << __PRETTY_FUNCTION__ << std::endl; }
    ~SharableObj() { std::cout << __PRETTY_FUNCTION__ << std::endl; }

    auto getPtr() { return shared_from_this(); }
};

void get_shared_ptr() {
    std::cout << __PRETTY_FUNCTION__ << std::endl;

    auto obj = std::make_shared<SharableObj>();
    auto same_obj = obj->getPtr();
}

//How does it work?
//rough implementation of enable_shared_from_this
template<class T>
class enable_shared_from_this {
    mutable std::weak_ptr<T> weak_this;
public:
    shared_ptr<T> shared_from_this() {
        return shared_ptr<T>(weak_this);
    }

    template <class U> friend class shared_ptr;
};

template <class T>
class shared_ptr_ {

shared_ptr_(T* p) noexcept
{
//...
    if constexpr (std::is_convertible_v<T, std::enable_shared_from_this<T> >)
    {
        p->weak_this = shared_ptr<T>(*this);
    }
}
};

class Executor {
public:
    void execute(const std::function<void(void)>& task);
    //....
private:
/* Реализация thread_pool */
};

class Processor : public std::enable_shared_from_this<Processor> {
public:
    void processData(const std::string& data)
    {
        //we need to pass shared_ptr to queue, because when it will be really processing, the Client could already be died
        executor->execute([self = shared_from_this(), data]() {
            self->doProcessAndSave(data); //add tak to queue
        });
    }
    void doProcessAndSave(const std::string& data) {/* ... */}
private:
    std::unique_ptr<Executor> executor;
};

class Client {
public:
    void someMethod() {
        processor->processData("Some Data"); //send request for processing
    }
private:
 std::shared_ptr<Processor> processor;
};


int main(int argc, char *argv[]) {

    // shared_ptr_example();
    // size_of();
    // get_shared_ptr();
    cyclik_links();

    return 0;
}
