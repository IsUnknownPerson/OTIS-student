#include <array>
#include <iostream>
#include <string>

int main() {
    std::string value = "First test";

    // auto wrongLambda = [&&value]() {
    //     // do something
    // };


    // C++14 - capture with an initializer
    auto lambda = [val = std::move(value)]() {
        std::cout << "Hello from lambda function with r-value: " << val << std::endl;
    };
    lambda();
    std::cout << "value now is: " << value << std::endl;



    // C++17
    auto getSize = [] { return 42; };
    
    [[maybe_unused]]
    std::array<int, getSize()> arr;

    auto stillConstexpr = []() constexpr {
        int value = 0;
        return 42;
    };
    [[maybe_unused]] std::array<int, stillConstexpr()> arr3;

    return 0;
}