#include <iostream>

[[noreturn]] void func() {
    std::abort();
}


[[deprecated]] int very_old_func() {
    return 76;
}

int switchFunc(int value) {
    int result = 0;
    switch(value) {
        case 0:
            result = 10;
            [[fallthrough]];
        case 1:
            result += 15;
            break;
        case 3:
            result = 72;
            [[fallthrough]];
        case 4:
            result += 15;
            break;
        default:
            result = 777;
    }
    return result;
}

[[nodiscard]]
int funcNoDiscard() {
    return 743;
}

int main() {
    [[maybe_unused]]
    int someValue = 0;

    // std::cout << func() << std::endl;
    // std::cout << very_old_func() << std::endl;

    switchFunc(123);

    funcNoDiscard();

    int value = 77;

    return 0;
}