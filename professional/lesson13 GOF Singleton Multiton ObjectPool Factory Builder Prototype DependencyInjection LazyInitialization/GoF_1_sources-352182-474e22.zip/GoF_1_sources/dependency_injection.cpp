// Внедрение зависимости (Dependency Injection)

#include <exception>
#include <iostream>
#include <string>

#include <gtest/gtest.h>
#include <gmock/gmock.h>

//motivation
class PostgresStorage_
{
public:
    PostgresStorage_(const std::string& connectionString)
    {
        //connect to db
    }
public:
    void execute_query()
    {
        std::cout << "postgres\n";
    }
};

class Report_
{
    PostgresStorage_ storage;
public:
    void print()
    {
        storage.execute_query();
        std::cout << "done" << std::endl;
    }
};

//DI example
class IStorage
{
public:
    virtual void execute_query() = 0;
};

class PostgresStorage : public IStorage
{
public:
    PostgresStorage(const std::string& connectionString)
    {
        //connect to db
    }
public:
    void execute_query() override
    {
        std::cout << "postgres\n";
    }
};

class Report
{
    IStorage* storage;
public:
    Report(IStorage* storage_) : storage(storage_)
    {
    }

    void print()
    {
        storage->execute_query();
        std::cout << "done" << std::endl;
    }
};

class MockStorage : public IStorage {
 public:
    MOCK_METHOD(void, execute_query, (), (override));
};

TEST(Report, PrintTest)
{
    MockStorage mock;
    EXPECT_CALL(mock, execute_query());
    Report report(&mock);
    report.print();
}

class BaseStorage
{
public:
    BaseStorage(const std::string& connectionString)
    {
        //connect to db
    }
public:
    virtual void execute_query()
    {
        std::cout << "BaseStorage::execute_query()" << std::endl;
    }
};

class MyStorage : public BaseStorage
{
public:
    MyStorage(const std::string& connectionString)
        : BaseStorage(connectionString)
    {
        //connect to db
    }
public:
    void execute_query() override
    {
        std::cout << "MyStorage::execute_query()" << std::endl;
    }
};

void func(BaseStorage& storage)
{
    storage.execute_query();
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();

    MyStorage s("str");
    func(s);
}
