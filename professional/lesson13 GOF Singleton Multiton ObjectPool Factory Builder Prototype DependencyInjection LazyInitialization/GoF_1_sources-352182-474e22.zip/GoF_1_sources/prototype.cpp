// Прототип (Prototype)

#include <iostream>
#include <map>
#include <memory>

//motivation
class Connection_
{
public:
    virtual ~Connection_() = default;
    virtual void connection() = 0;
};

class TcpConnector_ : public Connection_
{
public:
    void connection() override
    {
        std::cout << "tcp connection" << std::endl;
    }
};

class UdpConnector_ : public Connection_
{
public:
    void connection() override
    {
        std::cout << "udp connection" << std::endl;
    }
};

void func(std::unique_ptr<Connection_> c)
{
    //How to get copy of c?
}

void test_connection()
{
    std::unique_ptr<Connection_> c = std::make_unique<TcpConnector_>();
    func(std::move(c));
}

//prototype example
class Connection
{
public:
    virtual ~Connection() = default;

    virtual void connection() = 0;

    virtual std::unique_ptr<Connection> clone() = 0; //key method of prototype pattern
};

class TcpConnector : public Connection
{
public:
    void connection() override
    {
        std::cout << "tcp connection" << std::endl;
    }
public:
    std::unique_ptr<Connection> clone() override
    {
        return std::make_unique<TcpConnector>();
    }
};

class UdpConnector : public Connection
{
public:
    void connection() override
    {
        std::cout << "udp connection" << std::endl;
    }
public:
     std::unique_ptr<Connection> clone() override
    {
        return std::make_unique<UdpConnector>();
    }
};

int main()
{
    std::unique_ptr<Connection> c = std::make_unique<TcpConnector>();

    //...
    std::cout << "primary" << std::endl;
    c->connection();

    auto mirror = c->clone();
    std::cout << "mirror" << std::endl;
    mirror->connection();

    return 0;
}
