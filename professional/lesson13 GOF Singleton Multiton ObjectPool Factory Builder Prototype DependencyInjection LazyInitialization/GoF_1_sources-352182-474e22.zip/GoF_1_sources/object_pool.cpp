// Объектный пул (Object pool)

#include <atomic>
#include <exception>
#include <iostream>
#include <string>
#include <vector>
#include <array>
#include <memory>
#include <functional>
#include <thread>

class Connection
{
};

//for instance database connection pool
class ConnectionPool
{
private:
    using ConnectionPtr = std::unique_ptr<Connection>;
    struct ConnectionBlock {
        ConnectionPtr connection;
        bool busy;
    };

    std::vector<ConnectionBlock> m_pool;

public:
    Connection* get() {
        for (size_t i = 0; i < m_pool.size(); ++i) {
            if (!m_pool[i].busy) {
                m_pool[i].busy = true;
                return m_pool[i].connection.get();
            }
        }

        auto block = ConnectionBlock{
            ConnectionPtr{new Connection}, 
            true
        };
        m_pool.emplace_back(std::move(block));

        return m_pool.back().connection.get();
    }

    void put(Connection* object) {
        for (size_t i = 0; i < m_pool.size(); ++i) {
            if (m_pool[i].connection.get() == object) {
                m_pool[i].busy = false;
                break;
            }
        }
    }

    ~ConnectionPool() = default;
};

void use_connection_pool()
{
    ConnectionPool pool;

    auto report_conn = pool.get();
    pool.put(report_conn);

    auto admin_conn = pool.get();
    pool.put(admin_conn);
}

template <class T>
class ThreadSafeQueue
{
public:
    bool TryPop(T&) { return true; }
    void Push(T) {}
};

class ThreadPool
{
public:
    ThreadPool()
        : done(false)
    {
        unsigned threadCount = std::thread::hardware_concurrency();
        if (threadCount == 0)
        {
            threadCount = 4;
        }
        try
        {
            for (unsigned i = 0; i < threadCount; ++i)
            {
                threads.push_back(std::thread(&ThreadPool::WorkerThread, this));
            }
        }
        catch(const std::exception& e)
        {
            done = true;
            throw;
        }
        
    }

    ~ThreadPool()
    {
        done = true;
    }

    template <typename FunctionType>
    void submit(FunctionType f)
    {
        workQueue.Push(std::function<void()>(f));
    } 
private:
    void WorkerThread()
    {
        while (!done)
        {
            std::function<void()> task;
            if (workQueue.TryPop(task))
            {
                task();
            }
            else
            {
                std::this_thread::yield();
            }
        }
    }
private:
    std::atomic_bool done;
    ThreadSafeQueue<std::function<void()>> workQueue;
    std::vector<std::thread> threads;
};

int main()
{
    use_connection_pool();
    return 0;
}
