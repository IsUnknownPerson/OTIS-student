#include "pretty.h"

#include <iostream>
#include <string>
#include <chrono>

struct Hz
{
  unsigned long long val;
  unsigned long long get() const { return val; }
};

// warning: literal operator suffixes not preceded by ‘_’ are reserved for future standardization [-Wliteral-suffix]
//Allows integer, floating-point, character, and string literals
//to produce objects of user-defined type by defining a user-defined suffix.
Hz operator""_Hz(unsigned long long val)
{
  std::cout << __PRETTY_FUNCTION__ << std::endl;
  return Hz{val};
}

struct MHz
{
  long double val;
  unsigned long long hz() const { return (unsigned long long)(0.5 + val * 1000000000); }
  long double mhz() const { return val; }
};

MHz operator""_MHz(long double val)
{
  std::cout << __PRETTY_FUNCTION__ << std::endl;
  return MHz{val};
}

void example1()
{
  std::cout << std::endl << "example1: " << std::endl;

  auto gsm = 900000000_Hz; // -> operator""_Hz(900000000);
  auto dcs = 1900000000_Hz; // -> operator""_Hz(1900000000);
  std::cout << "gsm.get() = " << gsm.get() << " ; dcs.get() = " << dcs.get() << std::endl;

  auto wifi = 2.4_MHz; // -> operator""_MHz(2400);
  std::cout << "wifi.mhz() = " << wifi.mhz() << " ; wifi.hz() = " << wifi.hz() << std::endl;
}

// Compile error.
// int operator""_Bool(bool value)
// {
//   return 0;
// }

long double operator""_E(long double value)
{
  return value;
}

void example2()
{
  std::cout << std::endl << "example2: " << std::endl;

  // Compile error!
  //auto mhz850 = 850.0_MHz.mhz(); // error: unable to find numeric literal operator ‘operator""_MHz.mhz’
  auto mhz850 = 850.0_MHz .mhz();
  std::cout << "850.0_MHz`space`.mhz() = " << mhz850 << std::endl;

  // Compile error!
  //auto x = 6.67384_E-11; // error: unable to find numeric literal operator ‘operator""_E-11’
  auto x = 6.67384_E - 11;

  std::cout << 6.67384E-11 << std::endl;
  std::cout << "x = " << x << std::endl;
}

std::string operator""_english(const char * s, size_t n)
{
  std::cout << __PRETTY_FUNCTION__ << std::endl;
  std::cout << s << " " << n << std::endl;
  return "sorok dva";
}

void example3()
{
  std::cout << std::endl << "example3:" << std::endl;

  auto c = "42"_english;
  std::cout << "c = " << c << std::endl << std::endl;

  {
      using namespace std::string_literals;
      using namespace std::literals;

      auto d = std::string("hello\0world"); // s
      auto e = "hello\0world"s; // s
      std::cout << "d = " << d << std::endl;
      std::cout << "e = " << e << std::endl;
  }

  {
//C++14
    using namespace std::chrono_literals;
    // std::chrono::seconds
    auto seconds = 123s;
    std::cout << "seconds.count() = " << seconds.count() << std::endl;

    // Compile error!
    // 123s.count();
    // Ok
    std::cout << "123s`space`.count() = " << 123s .count() << std::endl;
  }
}

int main(int, char *[])
{
  example1();
  example2();
  example3();
  return 0;
}
