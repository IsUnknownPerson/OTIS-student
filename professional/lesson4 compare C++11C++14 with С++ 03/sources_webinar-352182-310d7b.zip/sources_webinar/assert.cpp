#include <iostream>
#include <cassert>
#include <cmath>

double my_sqrt(double value)
{
  return std::sqrt(value);
}

void example1()
{
  double value = 4.0;

  assert(my_sqrt(value) == 2.0);
  //assert(my_sqrt(value) == 2.1); // Ooops (только в случае Debug-сборки)

  int i = 0;
  //static_assert(i == 0, "failed"); // non-constant condition for static assertion (‘int i’ is not const)

  static_assert(true, "failed");

  const int j = 0;
  static_assert(j == 0, "failed foo");
}

int main(int, char *[])
{
  example1();
  return 0;
}


#include <type_traits>

template <class T>
void swap(T& a, T& b)
{
    static_assert(std::is_copy_constructible<T>::value,
                  "Swap requires copying");
    static_assert(std::is_nothrow_copy_constructible<T>::value
               && std::is_nothrow_copy_assignable<T>::value,
                  "Swap requires nothrow copy/assign");
    auto c = b;
    b = a;
    a = c;
}


const int MyLibraryVersion = 144;

static_assert(MyLibraryVersion > 100, "Old versions are not supported!");


#include <climits>

static_assert((CHAR_BIT) == 8, "Usupported system!");
