#include <iostream>


namespace motivation
{
  enum Alphabet
  {
    a,
    b,
    c,
  };

  void func(Alphabet) { }
  void func2(int) { }

  void example()
  {
    Alphabet value = Alphabet::a; // it works. nice!
    Alphabet value2 = a; // it works also. bad :(

    func(value); // it works
    func2(value); // it works also
  }


  struct GoodAlphabet
  {
    enum
    {
      d = 1,
      e = 2,
      f = 3,
    };
  };

  void example2()
  {
    auto d = GoodAlphabet::d;
    // hm... we can't name a type?
    int value = 2;
    switch(value)
    {
    case GoodAlphabet::d:
      std::cout << "d" << std::endl;
      break;
    case GoodAlphabet::e:
      std::cout << "e" << std::endl;
      break;
    case GoodAlphabet::f:
      std::cout << "f" << std::endl;
      break;
    default:
      break;
    }
  }
}

namespace advanced
{
  namespace constants
  {
    enum Flag
    {
      d,
      e,
      f,
    };
  }

  void example()
  {
    constants::Flag value = constants::Flag::d; // it works
    constants::Flag value2 = constants::d; // it works also
    // constants::Flag value2 = d;
  }
}

namespace basics
{
  enum class Digit : uint64_t
  {
    one = 1,
    two = 193,
    three = 247,
  };

  void func(Digit) { }
  void func2(uint64_t) { }
  void func3(int) { }

  void example()
  {
    //Digit value = one; // error: ‘one’ was not declared in this scope; did you mean ‘basics::Digit::one’?
    Digit value = Digit::one;

    func(value); // it works
    //func2(value); // error: cannot convert ‘basics::Digit’ to ‘uint64_t’ {aka ‘long unsigned int’}
    func2(static_cast<uint64_t>(value)); // it works
  }

}

int main(int, char *[])
{
  motivation::example();
  basics::example();
  advanced::example();

  return 0;
}
