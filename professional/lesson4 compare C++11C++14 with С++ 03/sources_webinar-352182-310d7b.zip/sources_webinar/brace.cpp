#include <iostream>
#include <vector>
#include <map>
#include <cstring>

namespace c_style_initialization {

struct MyWidget
{
    int i;
};

void default_initialization()
{
    int i;
    MyWidget widget;
    //std::cout << widget.i;
}

struct WithConversion
{
    WithConversion(double) {}
};

void copy_initialization()
{
    int i = 5; // T object = other
    WithConversion w = 1; //permorms conversion
}

int square(int i) //pass by value is copy initialization
{
    return i * i; //return by value is copy initialization
}

struct Widget {
    int i;
    int j;
};

struct WidgetExt {
    Widget w;
    int k;
};

void aggregate_initialization()
{
    int a[100] = {};
    int k[] = {1, 2, 3, 4};

    Widget w = {1, 2};
    Widget w2 = {1};
    std::cout << w2.j << std::endl;

    WidgetExt wExt = {1, 2};
    std::cout << wExt.k << std::endl;
}

void static_initialization()
{
    static int i = 3;
    static int j;
}
}

namespace cpp98_initialization
{
    struct DirectInit
    {
        DirectInit(int i_, int j_)
            : i(i_)
            , j(j_)
        {}

        int i;
        int j;
    };

    void direct_initialization()
    {
        int i(3); //no difference with copy init for built-in types
        DirectInit direct(1, 2); //can take more than 1 arg
    }

    struct Sample {};
    struct SampleExt
    {
        SampleExt(Sample) {}
        void some_func();
    };

    void most_vexing_parse()
    {
         //can be interpreted as a sampleExt function
        //input: pointer to function with no args and returning Sample
        //output: SampleExt
        SampleExt sampleExt((Sample())); //add extra () around Sample() to compile

        //sampleExt.some_func();
    }
}

namespace cpp03_initialization
{
    struct Widget {
        Widget() {}
        int i;
    };

    void value_initialization() // object is constructed with an empty initializer, e.g. T()
    {
        Widget w = Widget(); //call user provided ctor, no zero init;
        int i = int(); //zero init
    }

    void motivation()
    {
        std::vector<int> v;
        v.reserve(5);
        v.push_back(1);
        v.push_back(2);
        v.push_back(3);
        v.push_back(4);
        v.push_back(5);
    }
}

namespace cpp11_initialization
{
    struct Widget {
        int i;
        int j;
    };
    void list_initialization()
    {
        int i{3}; // direct init for built-in
        int j = {3};

        Widget widget {1, 2}; //aggregate init for aggregates
        Widget widget2 = {1, 2};
        int z[4] {1, 2};

        std::vector<int> v {1, 2, 3, 4, 5};
        std::vector<int> v2 = {1, 2, 3, 4, 5}; //How does it work?
    }

    template <class T>
    class RawSample {
    public:
        RawSample(std::initializer_list<T> l)
            : size(l.size())
        {
            ptr = new T[size];
            std::memcpy(ptr, l.begin(), size * sizeof(T));
            std::cout << "constructed with a " << l.size() << "-element list\n";
        }
        ~RawSample()
        {
            delete[] ptr;
        }

    private:
        std::size_t size;
        T* ptr;
    };

    template <class T>
    class NoInitializerList
    {
    public:
        NoInitializerList(T val_)
            : val(val_)
        {
            std::cout << "NoInitializerList ctor\n";
        }

/*      NoInitializerList(std::initializer_list<T> val_)
            : val(val_.size())
        {
            std::cout << "NoInitializerList ctor\n";
        }
*/
    private:
        T val;
    };

    void initializer_list_init()
    {
        RawSample<int> raw {1, 2, 3, 4, 6}; //greedily find ctor that takes std::initializer_list<T>
        NoInitializerList<int> n {2}; //direct initialization, equal to NoInitializerList<int> n(2);
    }

    void AddSomeMess()
    {
      std::vector<int> values(10, 0);
      std::vector<int> values2{10, 0}; // Hm...
    }

    template <typename T, size_t N>
    auto test()
    {
        return std::vector<T>{N};
    }

    void AddMoreMess()
    {
        std::cout << test<int, 3>().size() << std::endl;
        std::cout << test<char, 3>().size() << std::endl;
        std::cout << test<std::string, 3>().size() << std::endl;
    }

    void nested_braces()
    {
        std::map<std::string, int> m {{"one", 1}, {"two", 2}};
        std::vector<std::string> v {"one", "two"};
        std::vector<std::string> v2 {{"one", "two"}};
    }

    template <class T>
    struct DefaultCtorSample
    {
        DefaultCtorSample() { std::cout << "default ctor\n";}
        DefaultCtorSample(std::initializer_list<T> l) {std::cout << "initializer_list ctor\n";}
    };

    void empty_braces()
    {
        int i{}; //zero init = value initialization
        Widget widget{}; //zero init for aggregates
        DefaultCtorSample<int> c{}; //call to default ctor
    }
}

namespace cpp14_initialization
{
    void auto_fixes()
    {
        auto i = 3; //int
        auto j(3);  //int
        auto k{3}; //int since C++14, ill-formed auto k{2, 3}
        auto l = {3}; //std::initializer_list<int> both in C++11, C++14
    }
}

int main(int, char *[])
{
  c_style_initialization::default_initialization();
  cpp98_initialization::most_vexing_parse();
  cpp11_initialization::initializer_list_init();
  cpp11_initialization::AddMoreMess();
  cpp11_initialization::empty_braces();

  return 0;
}
