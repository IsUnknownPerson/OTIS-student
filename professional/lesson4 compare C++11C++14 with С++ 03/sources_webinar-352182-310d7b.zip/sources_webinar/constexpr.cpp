#include <array>
#include <iostream>

int foo()
{
    return 6;
}

constexpr int foo2()
{
    return 10;
}

void constexpr_example1()
{
    const int i = 5;
    constexpr int k = 5;

    const int j = foo(); //runtime initialization
    //constexpr int l = foo();
    constexpr int m = foo2(); //compile-time initialization, better for perfomance

}

//C++11
constexpr int pow(int base, int exp)
{
     return (exp == 0 ? 1 : base * pow(base, exp - 1));
}

//C++14
constexpr int init()
{
    return 1;
}

constexpr int pow_cpp14(int base, int exp)
{
    auto result = init();
    for (int i = 0; i < exp; ++i)
          result *= base;
    return result;
}

void constexpr_example2()
{
    constexpr auto result = pow(2, 3);

    int base; //get from config
    int exp;
   // auto result2 = pow(base, exp);
}

struct Colour
{
   uint8_t red;
   uint8_t green;
   uint8_t blue;

   //C++11 ctor body is empty, all non-static data members must be initialised
   //C++14 ctor may not be empty
   constexpr Colour(uint8_t r, uint8_t g, uint8_t b)
    : red(r)
    , green(g)
    , blue(b)
   {}

   constexpr uint8_t GetRed() const
   {
       return red;
   }
};

int main(int, char*[])
{
    static constexpr Colour c {255, 0, 0};
    constexpr uint8_t r  = c.GetRed();

    return 0;
}
