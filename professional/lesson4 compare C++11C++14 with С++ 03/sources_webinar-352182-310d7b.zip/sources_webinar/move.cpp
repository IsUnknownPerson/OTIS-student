#include <iostream>
#include <string>

void example1()
{
  std::string name{"Vasia"};
  std::move(name);

  std::cout << "example1: " << name << std::endl;
}

void example2()
{
  std::string name{"Vasia"};

  std::string str = std::move(name);

  std::cout << "example2: " << name << std::endl;
}













//GCC sample
class string {
  char* _M_p; // The actual data.
  std::size_t	_M_string_length;

  enum { _S_local_capacity = 15 / sizeof(char) };

  union
  {
    char          _M_local_buf[_S_local_capacity + 1];
    std::size_t   _M_allocated_capacity;
  };
};

int main(int, char *[])
{
  example1();
  example2();

  return 0;
}
