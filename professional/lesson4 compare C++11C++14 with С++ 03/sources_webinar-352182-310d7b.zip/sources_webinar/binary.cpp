#include <iostream>
#include <bitset>

int main()
{
  int value1 = 1'234'567; // dec (1234567)
  int value2 = 0xff;      // hex (255)
  int value3 = 0137;      // oct (95)

  //https://en.cppreference.com/w/cpp/language/integer_literal
  int value4 = 0b1111;    // binary (15) since C++14

  //The type of the integer literal is the first type in which the value can fit
  //if it doesn't fit int, it will try to fit unsigned int etc
  std::cout << "0b10101010 = " << 0b10101010 << std::endl;
  std::cout << "0b01010101 = " << 0b01010101 << std::endl;
  std::cout << "0b11111111 = " << 0b11111111 << std::endl;

  std::cout << "(int)(int8_t)0b11100000 = " << (int)(int8_t)0b11100000 << std::endl;
  std::cout << "+(int8_t)0b11100000 = " << +(int8_t)0b11100000 << std::endl; //unary operator+ performs integral promotion
  //char is promoted to int

  std::cout << "0b10000000u = " << 0b10000000u << std::endl; // суффикс u
  std::cout << "0b10000000ul = " << 0b10000000ul << std::endl;

  std::cout << std::hex << 0xff << std::endl;
  std::cout << std::bitset<8>(0b11100000) << std::endl;

  return 0;
}
