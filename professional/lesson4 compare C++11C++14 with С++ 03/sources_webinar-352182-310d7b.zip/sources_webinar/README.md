# Сравнение C++11/C++14 с С++ 03

Собираем исходные файлы:
```bash
mkdir ./build && cd ./build
cmake -DCMAKE_BUILD_TYPE=Release ..
cmake --build .
```

При проверке работы программы assert потребуется сменить `CMAKE_BUILD_TYPE`.
```bash
cmake -DCMAKE_BUILD_TYPE=Debug ..
cmake --build . --config Debug --target assert
./assert
```
