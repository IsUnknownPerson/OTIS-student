#include "pretty.h"

#include <iostream>
#include <string>

struct foo {

    foo(int val, int* ptr)
        : m_val (val)
        , m_ptr(ptr)
    {
        std::cout << __PRETTY_FUNCTION__ << std::endl; 
    };

    //constructor delegation adds ability to call another constructor of the same class
    //initializer list must consist of that one member initializer only
    //no recursion
    //call foo(val, nullptr), than body of foo(int val)
    foo(int val)
        : foo(val, nullptr)
    {
        std::cout << __PRETTY_FUNCTION__ << std::endl;
    };

    int m_val;
    int* m_ptr;
};

int main(int, char *[]) {

    int init = 42;
    foo g{init};

    return 0;
}
