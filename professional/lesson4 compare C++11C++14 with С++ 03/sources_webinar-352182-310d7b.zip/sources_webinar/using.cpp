#include <vector>

typedef int my_int_t; //alias my_int_t for int

void Interface(my_int_t i)
{
    my_int_t i_ = i;
}

//using my_int_tt = int;
using my_int_vector_t = std::vector<int>; //alias my_int_vector_t for std::vector<int>

template<typename T>
using my_vector_t = std::vector<T>; //using can be templated

int main(int, char *[])
{
  my_int_vector_t a;

  my_vector_t<int> b;
  my_vector_t<char> c;

  return 0;
}
