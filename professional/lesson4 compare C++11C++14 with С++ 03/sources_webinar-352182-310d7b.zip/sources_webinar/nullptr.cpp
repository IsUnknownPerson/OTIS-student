#include <iostream>

namespace basics {
  void func(int) { std::cout << __PRETTY_FUNCTION__ << std::endl; }
  void func(char *) { std::cout << __PRETTY_FUNCTION__ << std::endl; }

  void example()
  {
    // GCC - Compile error
    // error: error: call of overloaded ‘func(NULL)’ is ambiguous
    // MSVC - Ok - func(int) will be called
    //func(NULL);

    //int i = NULL; // warning: converting to non-pointer type ‘int’ from NULL [-Wconversion-null]
    char *p = NULL;

    // int is = nullptr; // error
    char *ps = nullptr; // There exist implicit conversions from nullptr to null pointer value of any pointer type
    func(nullptr);
  }
}

namespace middle
{
  void func(int* ) { std::cout << __PRETTY_FUNCTION__ << std::endl; }
  void func(char *) { std::cout << __PRETTY_FUNCTION__ << std::endl; }
  void func(nullptr_t) { std::cout << __PRETTY_FUNCTION__ << std::endl; }

  void example()
  {
    func(nullptr);
  }
}

template<typename T>
void processObject(T ptr)
{}

template<>
void processObject<nullptr_t>(nullptr_t ptr) = delete;

int main(int, char *[])
{
  basics::example();
  middle::example();

  return 0;
}
