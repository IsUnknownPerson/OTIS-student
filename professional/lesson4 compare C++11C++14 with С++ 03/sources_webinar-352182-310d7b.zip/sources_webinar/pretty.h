// если MSVC, переопределяем GNUшный pretty function, на аналогичный Edison Design Group C++
#if !defined(__PRETTY_FUNCTION__) && !defined(__GNUC__)
#  define __PRETTY_FUNCTION__ __FUNCSIG__
#endif
