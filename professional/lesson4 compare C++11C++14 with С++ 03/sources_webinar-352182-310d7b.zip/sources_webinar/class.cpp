#include <iostream>

struct base
{
    base() = default;
    base(base&&) = default;
    base(const base&) = default;

    virtual ~base() = default;

    base & operator=(const base& rhs) = default;
    base & operator=(base&& rhs) = default;
};

struct DefaultCtor
{
    DefaultCtor(int val) {}
    DefaultCtor() = default;
};

struct DefaultMoveCtor
{
    DefaultMoveCtor() = default;
    DefaultMoveCtor(DefaultMoveCtor& c) {}
    DefaultMoveCtor(DefaultMoveCtor&& c) = default;
};

void Sample()
{
    DefaultMoveCtor m;
    DefaultMoveCtor m2(std::move(m));
}

struct bar : base
{
};

struct DefaultSample
{
    DefaultSample() = default; //not user-provided
    DefaultSample(int val_);
    //DefaultSample() {} // user-provided ctor
    int val;
};

//DefaultSample::DefaultSample() = default; //user-provided

DefaultSample getSample()
{
    return DefaultSample();
}

void example()
{
    std::cout << getSample().val;
}


struct foo
{
  foo() = delete;
  ~foo() = delete; //possible, but weird
  foo(int value) { }

  void func(int i) {}
  void func(char c) = delete;
};

template<typename T>
void processPointer(T* ptr)
{}

template<>
void processPointer<void>(void* ptr) = delete;

class WithFriend
{
friend class HasAccess;
public:
    WithFriend() = default;
private:
    WithFriend(const WithFriend& a);
};

class HasAccess
{
public:
    HasAccess()
    {
        WithFriend a;
        WithFriend b(a);
    }
};

struct Base
{
    virtual void MyFunction(int a, double b) {};
    virtual void foo() {};
};

struct A : Base
{
    void MyFunction(int a, double b) override { }
    //virtual void MyFuncion(int a, double b) { }


    void foo() final {}; // Base::foo is overridden and A::foo is the final override
//    void bar() final; // Error: bar cannot be final as it is non-virtual
};

void override_example()
{
    Base* base = new A();
    base->MyFunction(1, 2.4);
    delete base;
}

struct B final : A // struct B is final
{
//    void foo() override; // Error: foo cannot be overridden as it is final in A
};

//struct C : B {}; // Error: B is final

class IAbstract
{
public:
  virtual void DoSomething() = 0;
  virtual ~IAbstract() = default;
};

class CDerived : public IAbstract
{
public:
  void DoSomething() final {} //for optimization
  void Blah( void ) { DoSomething(); } //if DoSomething() is final, direct call or inline
  //otherwise use vtable
};

class CCDerived : public CDerived
{
public:
 // void DoSomething() final {}
};

int main(int, char *[])
{
  bar b;

  return 0;
}
