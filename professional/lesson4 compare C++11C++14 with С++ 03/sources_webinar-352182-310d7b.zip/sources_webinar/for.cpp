#include <iostream>
#include <vector>
#include <algorithm>

int main(int, char *[])
{
  int a[10];
  for(const auto& i : a) //for-range loop
  {
    std::cout << "const auto& i = " << i << std::endl;
  }

  std::vector<int> values = {1, 2 , 3, 4, 5, 6};

  int counter = 0;
  for(auto& i : values)
  {
    i = i + 42;
    values.push_back(42); // bad code. iterators invalidation
    std::cout << "auto& i = " << i << std::endl;
  }

  std::string s{"hello"};
  for(auto c: s)
  {
    std::cout << c << std::endl;
  }

  struct MyStruct
  {
      int val;
  };
  std::vector<MyStruct> structVec;
  for(const auto& s : structVec)
  {
      break;
      //continue
  }

  for(const auto& s : {"one", "two", "three"})
  {
      break;
      //continue
  }

  /*
    auto && __range = range_expression ;
    auto __begin = begin_expr(__range);
    auto __end = end_expr(__range);
    for (;__begin != __end; ++__begin) {
        range_declaration = *__begin;
        loop_statement
    }
  */

  std::vector<int> v {101, 23, 45, 56};
  std::for_each(v.begin() + 3, v.end(), [](auto& i){ i += 3; }); //any iterators

  return 0;
}
