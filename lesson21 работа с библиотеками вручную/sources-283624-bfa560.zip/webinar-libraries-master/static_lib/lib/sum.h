
#pragma once

namespace library {

	int sum(int a, int b);
	
	double sum(double a, double b);

} // namespace library