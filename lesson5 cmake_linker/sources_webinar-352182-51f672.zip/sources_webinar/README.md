# The practice part of the webinar about linkage

## Build

```bash
mkdir build
cd build
cmake ..
cmake --build .
```
