#pragma once

#include <string>

std::string getCurrentDateTime();