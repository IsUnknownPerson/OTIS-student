#include <iostream>
#include "functions.h"
#include "constants.h"

int main()
{
    SomeClass c;
    function_impl();
    std::cout << globalVar;

	return 0;
}
