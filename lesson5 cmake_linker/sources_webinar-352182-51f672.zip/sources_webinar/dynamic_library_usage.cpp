#include "calculation.h"

#include <iostream>

int main()
{

	std::cout << "make_some_calculation = " << make_some_calculation(1, 2) << std::endl;

	return 0;
}