#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void function_impl();
extern int globalVar;

class SomeClass
{
};

#endif // FUNCTIONS_H
