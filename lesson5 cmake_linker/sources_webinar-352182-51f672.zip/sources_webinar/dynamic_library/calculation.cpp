#include "calculation.h"

#include <iostream>

int make_some_calculation(int arg1, int arg2)
{
	std::cout << "Hello from super calculator V1!" << std::endl;
	return arg1 + arg2;
}
