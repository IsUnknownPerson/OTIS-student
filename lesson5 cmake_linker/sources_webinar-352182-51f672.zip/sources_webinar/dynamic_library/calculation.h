#pragma once

int make_some_calculation(int arg1, int arg2);