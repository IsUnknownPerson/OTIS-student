#include "datetime.h"

#include <iostream>

int main()
{
	std::cout << "getCurrentDateTime = " << getCurrentDateTime() << std::endl;

	return 0;
}