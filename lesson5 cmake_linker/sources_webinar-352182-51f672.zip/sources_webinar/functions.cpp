#include "functions.h"

int globalVar = 5;

void function_impl()
{
}
