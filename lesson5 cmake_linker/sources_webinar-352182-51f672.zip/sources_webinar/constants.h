#ifndef CONSTANTS_H
#define CONSTANTS_H

#include "functions.h"

#endif // CONSTANTS_H
