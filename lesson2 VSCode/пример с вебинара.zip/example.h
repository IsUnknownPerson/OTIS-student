#pragma once

void example_function();