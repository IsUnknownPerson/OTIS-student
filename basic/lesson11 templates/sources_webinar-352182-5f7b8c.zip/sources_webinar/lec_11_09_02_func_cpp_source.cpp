// do not include corresponding header


template <typename T> 
T compute_sum(T a, T b)
{
    return a + b;
}
