#pragma once

template <typename T> 
T compute_mult(T a, T b);
