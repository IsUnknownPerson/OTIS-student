#pragma once

template <typename T> 
T compute_sum(T a, T b);

#include "lec_11_09_02_func_cpp_source.cpp"
