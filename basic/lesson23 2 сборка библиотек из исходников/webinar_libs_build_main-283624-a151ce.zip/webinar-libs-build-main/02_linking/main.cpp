
// https://github.com/google/googletest.git
#include <gtest/gtest.h>

TEST(Simple, alone) {
    ASSERT_EQ(4, 2 * 2);
}
