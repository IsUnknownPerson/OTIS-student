#pragma once

namespace sumLib {

    int sum(int a, int b);

    int getVersion();

}