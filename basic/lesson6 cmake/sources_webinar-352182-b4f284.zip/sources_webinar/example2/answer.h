#pragma once

int getAnswer();
