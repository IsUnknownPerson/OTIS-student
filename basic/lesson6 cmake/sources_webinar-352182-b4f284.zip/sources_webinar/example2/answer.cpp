

int getAnswer() { return 42; }
