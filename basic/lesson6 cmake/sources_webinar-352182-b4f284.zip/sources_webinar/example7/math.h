#pragma once

namespace math {

    int sum(int a, int b);

}