#include "math.h"

namespace math {

    int sum(int a, int b) {
        return a + b + 1;
    }

}