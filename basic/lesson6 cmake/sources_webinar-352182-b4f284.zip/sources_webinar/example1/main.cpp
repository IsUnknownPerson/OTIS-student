#include <iostream>

int main(int, char**) {

    std::cout << "Hello from the first CMake example!" << std::endl;

    return 0; 
}