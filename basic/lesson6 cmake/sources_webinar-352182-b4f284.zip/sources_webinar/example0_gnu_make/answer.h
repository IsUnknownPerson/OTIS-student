
#pragma once

int getAnswer();