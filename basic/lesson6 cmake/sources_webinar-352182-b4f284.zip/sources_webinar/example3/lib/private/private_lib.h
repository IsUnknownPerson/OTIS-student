#pragma once

#define MY_VAR 312
