#pragma once

namespace lib {

    int makeSomeSuperJob();

    int getVersion();

}