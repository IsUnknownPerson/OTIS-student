#pragma once

namespace dynamic_lib {

    int makeSomeSuperJob();

}