// Calculate greatest common divisor using Euclidean algorithm

#include <cstdlib>
#include <iostream>

unsigned int gcd(unsigned int a, unsigned int b) {
  do {
    const auto r = a % b;
    a = b;
    b = r;
  } while (b != 0);

  return a;
}

int main(const int, char *argv[]) {
  const auto a = std::atoi(argv[1]);
  const auto b = std::atoi(argv[2]);

  const auto result = gcd(a, b);

  std::cout << result << std::endl;

  return EXIT_SUCCESS;
}