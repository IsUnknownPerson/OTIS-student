#include <cstring>
#include <exception>
#include <iostream>
#include <new>

class Person {
 public:
  Person() = default;

  Person(const char *first_name, const char *last_name) {
    {
      const size_t len = std::strlen(first_name);
      m_first_name = new char[len + 1];
      std::strncpy(m_first_name, first_name, len);
    }
    {
      const size_t last_name_length = std::strlen(last_name);
      m_last_name = new char[last_name_length + 1];
      std::strncpy(m_last_name, last_name, last_name_length);
    }
  }

  Person(Person &) = default;
  Person(Person &&) = default;

  ~Person() {
    delete[] m_first_name;
    delete[] m_last_name;
  }

  Person &operator=(const Person &) = default;
  Person &operator=(Person &&) = default;

 private:
  char *m_first_name;
  char *m_last_name;
};

int main(const int, char *[]) {
  Person john{"John", "Smith"};

  return EXIT_SUCCESS;
}