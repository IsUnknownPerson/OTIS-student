// Calculate greatest common divisor using Euclidean algorithm

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <string_view>
#include <system_error>

////////////////////////////////////////////////////////////////////////////////

enum class GcdErrc {
  NoError = 0,
  NotEnoughParams,
  NonDigitChar,
  NegativeNumber,
  TooLargeNumber,
  DivisionByZero,
};

class GcdException : public std::exception {
 public:
  explicit GcdException(const GcdErrc &code) : m_code{code} {}

  [[nodiscard]] const char *what() const noexcept override;

 private:
  const GcdErrc m_code;
};

const char *GcdException::what() const noexcept {
  switch (m_code) {
    case GcdErrc::NoError:
      return "No error";
    case GcdErrc::NotEnoughParams:
      return "Usage: gcd a b";
    case GcdErrc::NonDigitChar:
      return "Number parse error: all chars must be digits";
    case GcdErrc::NegativeNumber:
      return "Number parse error: input must be positive integer";
    case GcdErrc::TooLargeNumber:
      return "Number parse error: input number is too large";
    case GcdErrc::DivisionByZero:
      return "GCD error: division by zero";
    default:
      return "Unknown error";
  }
}

////////////////////////////////////////////////////////////////////////////////

unsigned int gcd(unsigned int a, unsigned int b);
unsigned int parse_unsigned(const char *source);
void check_argc(int argc);

int main(const int argc, char *argv[]) {
  try {
    check_argc(argc);

    const auto a = parse_unsigned(argv[1]);
    const auto b = parse_unsigned(argv[2]);

    const auto result = gcd(a, b);

    std::cout << result << "\n";

  } catch (const GcdException &ex) {
    std::cout << "GCD error: \"" << ex.what() << "\"" << std::endl;
    return EXIT_FAILURE;
  } catch (const std::exception &ex) {
    std::cout << "General error: \"" << ex.what() << "\"" << std::endl;
    return EXIT_FAILURE;
  } catch (...) {
    std::cout << "Unknown error" << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

void check_argc(const int argc) {
  if (argc >= 2) {
    return;
  }

  throw GcdException{GcdErrc::NotEnoughParams};
}

unsigned int gcd(unsigned int a, unsigned int b) {
  if (b == 0) {
    throw GcdException{GcdErrc::DivisionByZero};
  }

  do {
    const auto r = a % b;
    a = b;
    b = r;
  } while (b != 0);

  return a;
}

unsigned parse_unsigned(const char *source) {
  {
    const std::string_view view{source};
    if (!std::all_of(view.cbegin(), view.cend(), ::isdigit)) {
      throw GcdException{GcdErrc::NonDigitChar};
    }
  }

  const auto val = std::atoll(source);
  if (val < 0) {
    throw GcdException{GcdErrc::NegativeNumber};
  }

  if (val >
      static_cast<decltype(val)>(std::numeric_limits<unsigned int>::max())) {
    throw GcdException{GcdErrc::TooLargeNumber};
  }

  return static_cast<unsigned int>(val);
}
