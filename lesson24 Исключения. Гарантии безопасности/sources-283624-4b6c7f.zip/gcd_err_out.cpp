
#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <optional>
#include <string_view>

unsigned int gcd(unsigned int a, unsigned int b, int &err);
unsigned int parse_unsigned(const char *source, int &err);

int main(int argc, char *argv[]) {
  if (argc < 3) {
    std::cerr << "Usage: gcd a b\n";
    return EXIT_FAILURE;
  }

  int err = 0;
  const auto a = parse_unsigned(argv[1], err);
  if (err != 0) {
    return EXIT_FAILURE;
  }

  const auto b = parse_unsigned(argv[2], err);
  if (err != 0) {
    return EXIT_FAILURE;
  }

  const auto result = gcd(a, b, err);
  if (err != 0) {
    return EXIT_FAILURE;
  }

  std::cout << result << std::endl;

  return EXIT_SUCCESS;
}

unsigned int gcd(unsigned int a, unsigned int b, int &err) {
  if (b == 0) {
    std::cerr << "GCD error: division by zero" << std::endl;
    err = 1;
    return 0;
  }

  do {
    const auto r = a % b;
    a = b;
    b = r;
  } while (b != 0);

  err = 0;

  return a;
}

unsigned int parse_unsigned(const char *source, int &err) {
  {
    const std::string_view view{source};
    if (!std::all_of(view.begin(), view.end(), ::isdigit)) {
      std::cerr << "Number parse error: all chars must be digits" << std::endl;
      err = 1;

      return 0;
    }
  }

  // auto == long long
  const auto val = std::atoll(source);
  if (val < 0) {
    std::cerr << "Number parse error: input must be positive integer\n";
    err = 1;

    return 0;
  }

  if (val >
      static_cast<decltype(val)>(std::numeric_limits<unsigned int>::max())) {
    std::cerr << "Number parse error: input number is too large" << std::endl;
    err = 1;

    return 0;
  }

  err = 0;

  return static_cast<unsigned int>(val);
}
