// Calculate greatest common divisor using Euclidean algorithm

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <string_view>

unsigned int gcd(unsigned int a, unsigned int b);
unsigned int parse_unsigned(const char *str);

int main(const int argc, char *argv[]) {
  if (argc < 3) {
    std::cerr << "Usage: gcd a b" << std::endl;
    return EXIT_FAILURE;
  }

  const auto a = parse_unsigned(argv[1]);
  if (a == 0) {
    return EXIT_FAILURE;
  }

  const auto b = parse_unsigned(argv[2]);
  if (b == 0) {
    return EXIT_FAILURE;
  }

  const auto result = gcd(a, b);
  if (result == 0) {
    return EXIT_FAILURE;
  }

  std::cout << result << std::endl;

  return EXIT_SUCCESS;
}

unsigned int gcd(unsigned int a, unsigned int b) {
  if (b == 0) {
    std::cerr << "GCD error: division by zero" << std::endl;
    return 0;
  }

  do {
    const auto r = a % b;
    a = b;
    b = r;
  } while (b != 0);

  return a;
}

unsigned int parse_unsigned(const char *str) {
  {
    const std::string_view view{str};
    if (!std::all_of(view.cbegin(), view.cend(), ::isdigit)) {
      std::cerr << "Number parse error: all chars must be digits" << std::endl;
      return 0;
    }
  }

  // auto == long long
  const auto val = std::atoll(str);
  if (val < 0) {
    std::cerr << "Number parse error: input must be positive integer"
              << std::endl;
    return 0;
  }

  if (val >
      static_cast<decltype(val)>(std::numeric_limits<unsigned int>::max())) {
    std::cerr << "Number parse error: input number is too large" << std::endl;
    return 0;
  }

  return static_cast<unsigned>(val);
}
