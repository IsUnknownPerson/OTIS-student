#include <string>

class Person {
 public:
  Person(std::string first_name, std::string last_name)
      : m_first_name{std::move(first_name)},
        m_last_name{std::move(last_name)} {}

  Person(const Person &) = default;
  Person(Person &&) = default;

  Person &operator=(const Person &other) {

    // auto == std::string
    auto first_name_tmp = other.m_first_name;
    auto last_name_tmp = other.m_last_name;

    // no except  below
    m_first_name = std::move(first_name_tmp);
    m_last_name = std::move(last_name_tmp);

    return *this;
  }

  Person &operator=(Person &&other) = default;

  ~Person() = default;

 private:
  std::string m_first_name;
  std::string m_last_name;
};

int main() {
  Person john{"John", "Smith"};
  Person mary{"Mary", "Jane"};

  john = mary;
}
