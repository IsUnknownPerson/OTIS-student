#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <string_view>
#include <system_error>

enum class GcdErrc {
  NoError = 0,
  NotEnoughParams,
  NonDigitChar,
  NegativeNumber,
  TooLargeNumber,
};

class gcd_category : public std::error_category {
 public:
  [[nodiscard]] const char *name() const noexcept override { return "gcd"; }

  [[nodiscard]] std::string message(int condition) const override;
};

std::string gcd_category::message(const int condition) const {
  switch (static_cast<GcdErrc>(condition)) {
    case GcdErrc::NoError:
      return "No error";
    case GcdErrc::NotEnoughParams:
      return "Usage: gcd a b";
    case GcdErrc::NonDigitChar:
      return "Number parse error: all chars must be digits";
    case GcdErrc::NegativeNumber:
      return "Number parse error: input must be positive integer";
    case GcdErrc::TooLargeNumber:
      return "Number parse error: input number is too large";
    default:
      return "Unknown error";
  }
}

std::error_condition make_error_condition(const GcdErrc &errc) {
  const static gcd_category gcd_err_category;
  return std::error_condition{static_cast<int>(errc), gcd_err_category};
}

unsigned int gcd(unsigned int a, unsigned int b, int &err);
unsigned int parse_unsigned(const char *source, std::error_condition &err);

int main(int argc, char *argv[]) {
  // auto == std::error_condition
  auto err = make_error_condition(GcdErrc::NoError);

  int gcd_err = 0;
  do {
    if (argc < 3) {
      err = make_error_condition(GcdErrc::NotEnoughParams);
      break;
    }

    const auto a = parse_unsigned(argv[1], err);
    if (err) {
      break;
    }

    const auto b = parse_unsigned(argv[2], err);
    if (err) {
      break;
    }

    int gcd_err = 0;
    const auto result = gcd(a, b, gcd_err);

    if (gcd_err != 0) {
      break;
    }

    std::cout << result << "\n";

  } while (false);

  if (err) {
    std::cerr << err.message() << std::endl;
    return EXIT_FAILURE;
  }

  if (gcd_err != 0) {
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

unsigned int gcd(unsigned int a, unsigned int b, int &err) {
  if (b == 0) {
    std::cerr << "GCD error: division by zero" << std::endl;
    err = 1;

    return 0;
  }

  do {
    const auto r = a % b;
    a = b;
    b = r;
  } while (b != 0);

  err = 0;

  return a;
}

unsigned int parse_unsigned(const char *source, std::error_condition &err) {
  {
    std::string_view view{source};
    if (!std::all_of(view.cbegin(), view.cend(), ::isdigit)) {
      err = make_error_condition(GcdErrc::NonDigitChar);
      return 0;
    }
  }

  // auto == long long
  const auto val = std::atoll(source);
  if (val < 0) {
    err = make_error_condition(GcdErrc::NegativeNumber);
    return 0;
  }

  if (val >
      static_cast<decltype(val)>(std::numeric_limits<unsigned int>::max())) {
    err = make_error_condition(GcdErrc::TooLargeNumber);
    return 0;
  }

  return static_cast<unsigned int>(val);
}
