#include <string>

class Person {
 public:
  Person(std::string first_name, std::string last_name)
      : m_first_name{std::move(first_name)},
        m_last_name{std::move(last_name)} {}

  Person(const Person &) = default;
  Person(Person &&) = default;

  Person &operator=(const Person &other) {
    // Copy and swap idiom.
    Person tmp{other};
    // swap(tmp);

    return *this;
  }

  Person &operator=(Person &&) = default;

  ~Person() = default;

  // Implement swap method
  void swap(Person &other) noexcept;

 private:
  std::string m_first_name;
  std::string m_last_name;
};

int main() {
  Person john{"John", "Smith"};
  Person mary{"Mary", "Jane"};

  john = mary;
}