#include <string>

class Person {
 public:
  Person(const char *first_name, const char *last_name)
      : m_first_name{first_name}, m_last_name{last_name} {}

  Person(const Person &) = default;
  Person(Person &&) = default;

  Person &operator=(const Person &other) {
    m_first_name = other.m_first_name;
    m_last_name = other.m_last_name;
    return *this;
  }

  Person &operator=(Person &&) = default;

  ~Person() = default;

 private:
  std::string m_first_name;
  std::string m_last_name;
};

int main() {
  Person john{"John", "Smith"};
  Person mary{"Mary", "Jane"};

  john = mary;
}
